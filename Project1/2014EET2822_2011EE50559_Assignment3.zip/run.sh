#! /bin/bash

mkdir   ARC_2014EET2822_Expt3
cp Code/*  ARC_2014EET2822_Expt3
cp Documentation/*  ARC_2014EET2822_Expt3

cd ./ ARC_2014EET2822_Expt3
make

./swlab_a3